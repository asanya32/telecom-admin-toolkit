#!/bin/bash

SERVICES=("kamailio" "rtpengine" "freediameter")
LOG="/var/log/telecom_monitor.log"

echo "[*] Service Status Check – $(date)" | tee -a "$LOG"

for svc in "${SERVICES[@]}"; do
    if systemctl is-active --quiet "$svc"; then
        echo "✔ $svc is running" | tee -a "$LOG"
    else
        echo "✖ $svc is NOT running. Attempting restart..." | tee -a "$LOG"
        sudo systemctl restart "$svc"
        sleep 1
        if systemctl is-active --quiet "$svc"; then
            echo "✔ $svc restarted successfully" | tee -a "$LOG"
        else
            echo "‼️ $svc failed to start" | tee -a "$LOG"
        fi
    fi
done

echo "Check complete."


