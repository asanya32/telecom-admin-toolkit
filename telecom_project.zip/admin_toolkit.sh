#!/bin/bash

# ====== Telecom Admin Toolkit ======
while true; do
    clear
    echo "========= Telecom Admin Toolkit ========="
    echo "1) Backup IMS Configs"
    echo "2) Monitor Telecom Services"
    echo "3) Parse SIP Logs"
    echo "4) Run VoIP Diagnostics"
    echo "5) Run Security Hardening Check"
    echo "6) View Logs"
    echo "7) Exit"
    echo "========================================="
    read -p "Choose an option: " opt

    case $opt in
        1)
            bash ~/telecom_scripts/backup_ims.sh
            read -p "Press Enter to continue..." ;;
        2)
            bash ~/telecom_scripts/monitor_services.sh
            read -p "Press Enter to continue..." ;;
        3)
            bash ~/telecom_scripts/parse_sip_logs.sh
            read -p "Press Enter to continue..." ;;
        4)
            sudo bash ~/telecom_scripts/voip_diag.sh
            read -p "Press Enter to continue..." ;;
        5)
            sudo bash ~/telecom_scripts/security_harden.sh
            read -p "Press Enter to continue..." ;;
        6)
            less /var/log/voip_diag.log ;;
        7)
            echo "Exiting..."; break ;;
        *)
            echo "Invalid option"; sleep 1 ;;
    esac
done

