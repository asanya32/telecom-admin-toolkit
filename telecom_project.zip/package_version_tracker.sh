#!/bin/bash
LOG_DIR=~/telecom_logs
LOG_FILE="$LOG_DIR/package_versions_$(date +%F).log"

mkdir -p "$LOG_DIR"
echo "==== Installed Telecom Packages as of $(date) ====" > "$LOG_FILE"

for pkg in sipp tshark tcpdump iperf3 rtpengine; do
    if command -v "$pkg" &> /dev/null; then
        echo "$pkg version:" >> "$LOG_FILE"
        "$pkg" -v >> "$LOG_FILE" 2>&1 || "$pkg" --version >> "$LOG_FILE" 2>&1
        echo "" >> "$LOG_FILE"
    else
        echo "$pkg is NOT installed." >> "$LOG_FILE"
    fi
done
