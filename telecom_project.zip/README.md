# Telecom Admin Toolkit

A Linux-based telecom lab environment project covering VoIP tools, monitoring, security, and automation.

## Phases Completed
- ✅ Phase 1: Environment Setup
- ✅ Phase 2: Disk Management
- ✅ Phase 3: User & Group Setup
- ✅ Phase 4: Scripting & Automation
- ✅ Phase 5: Service Monitoring
- ✅ Phase 6: Log Management
- ✅ Phase 7: Package & Tool Management
- ✅ Phase 8: Network & VoIP Troubleshooting
- ✅ Phase 9: Security Hardening
- ✅ Phase 10: Admin Toolkit Integration

## Screenshot Example (Phase 9)
![Phase 9 - Security Hardening](screenshots/phase9_screenshot.png)
