#!/bin/bash

BACKUP_DIR="$HOME/ims_backup/$(date +%Y%m%d_%H%M%S)"
CONFIG_PATHS=("/etc/kamailio" "/etc/rtpengine" "/etc/freediameter")

mkdir -p "$BACKUP_DIR"

echo "[*] Backing up IMS configs to $BACKUP_DIR..."

for path in "${CONFIG_PATHS[@]}"; do
    if [ -d "$path" ]; then
        cp -r "$path" "$BACKUP_DIR"
        echo "✔ Backed up: $path"
    else
        echo "✖ Skipped (not found): $path"
    fi
done

echo "Backup completed!"

