#!/bin/bash
echo "===== Hostname =====" > network_log.txt
date >> network_log.txt
hostname >> network_log.txt

echo -e "\n===== IP Address =====" >> network_log.txt
date >> network_log.txt
ip a >> network_log.txt

echo -e "\n===== Ping Test =====" >> network_log.txt
date >> network_log.txt
ping -c 4 8.8.8.8 >> network_log.txt
