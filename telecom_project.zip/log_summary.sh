#!/bin/bash

LOG_DIR="$HOME/telecom_logs"
SUMMARY_FILE="$LOG_DIR/weekly_summary_$(date +%F).log"

echo "===== Weekly Log Summary =====" > "$SUMMARY_FILE"
echo "Date: $(date)" >> "$SUMMARY_FILE"
echo "==============================" >> "$SUMMARY_FILE"
echo "" >> "$SUMMARY_FILE"

for log in "$LOG_DIR"/*.log; do
    echo "📄 Log File: $(basename "$log")" >> "$SUMMARY_FILE"
    echo "  ├─ Total lines: $(wc -l < "$log")" >> "$SUMMARY_FILE"
    echo "  ├─ Errors: $(grep -ci 'error' "$log")" >> "$SUMMARY_FILE"
    echo "  ├─ Warnings: $(grep -ci 'warn' "$log")" >> "$SUMMARY_FILE"
    echo "  └─ Restarts: $(grep -ci 'restart' "$log")" >> "$SUMMARY_FILE"
    echo "" >> "$SUMMARY_FILE"
done

echo "✅ Summary generated at $SUMMARY_FILE"
