#!/bin/bash

LOG_FILE="/log/sip.log"

echo -e "\e[34m[$(date)] Failed SIP Call Attempts (4xx):\e[0m"

grep "SIP/2.0 4" "$LOG_FILE" | while read -r line; do
  echo -e "\e[31m$line\e[0m"
done
