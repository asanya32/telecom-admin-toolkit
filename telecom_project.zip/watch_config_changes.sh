#!/bin/bash

WATCH_DIRS=("/etc/kamailio" "/etc/freediameter")
SNAPSHOT="$HOME/telecom_logs/config_checksum_snapshot.txt"
CURRENT="$HOME/telecom_logs/config_checksum_current.txt"
DIFF="$HOME/telecom_logs/config_diff_$(date +%F).log"

mkdir -p "$(dirname "$SNAPSHOT")"

# Generate current checksums
> "$CURRENT"
for dir in "${WATCH_DIRS[@]}"; do
    if [ -d "$dir" ]; then
        find "$dir" -type f -exec sha256sum {} \; >> "$CURRENT"
    fi
done

# Compare to previous snapshot
if [ -f "$SNAPSHOT" ]; then
    diff "$SNAPSHOT" "$CURRENT" > "$DIFF"
    if [ -s "$DIFF" ]; then
        echo -e "\e[31m[$(date '+%F %T')] ❗ CONFIG CHANGES DETECTED!\e[0m"
        cat "$DIFF"
    else
        echo -e "\e[32m[$(date '+%F %T')] ✅ No config changes.\e[0m"
        rm -f "$DIFF"
    fi
else
    echo "Creating initial checksum snapshot..."
fi

# Update snapshot
cp "$CURRENT" "$SNAPSHOT"
