#!/bin/bash
LOG_FILE="/var/log/voip_diag.log"
HOSTS=("8.8.8.8" "google.com" "sip2sip.info")

echo "========== VOIP NETWORK DIAGNOSTICS: $(date) ==========" >> "$LOG_FILE"

# Basic Ping Test
for host in "${HOSTS[@]}"; do
  echo ">> Pinging $host" >> "$LOG_FILE"
  ping -c 4 "$host" >> "$LOG_FILE" 2>&1
done

# Traceroute to VoIP service
echo -e "\n>> Traceroute to sip2sip.info" >> "$LOG_FILE"
traceroute sip2sip.info >> "$LOG_FILE" 2>&1

# Nmap basic port scan
echo -e "\n>> Nmap scan on localhost SIP/SSH" >> "$LOG_FILE"
nmap -p 22,5060,5061 localhost >> "$LOG_FILE" 2>&1

# Check open sockets
echo -e "\n>> Active listening services (ss -tulpen)" >> "$LOG_FILE"
ss -tulpen >> "$LOG_FILE" 2>&1

echo -e "\n✅ Diagnostics complete. Log saved to $LOG_FILE\n"
