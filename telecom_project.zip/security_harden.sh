#!/bin/bash

LOG="/var/log/security_audit.log"

echo "[*] Security Hardening Check – $(date)" >> "$LOG"

echo "== Fail2Ban Status ==" >> "$LOG"
sudo fail2ban-client status >> "$LOG" 2>&1

echo "== Running chkrootkit ==" >> "$LOG"
sudo chkrootkit >> "$LOG" 2>&1

echo "== Running Lynis (quick audit) ==" >> "$LOG"
sudo lynis audit system --quick >> "$LOG" 2>&1

echo "Audit complete. Log: $LOG"
