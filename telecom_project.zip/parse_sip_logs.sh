#!/bin/bash

LOGFILE="/var/log/kamailio.log"
OUTPUT="$HOME/failed_calls_$(date +%Y%m%d).txt"

echo "[*] Extracting failed SIP calls from $LOGFILE..."

grep -Ei "SIP/2.0 [45][0-9][0-9]" "$LOGFILE" > "$OUTPUT"

echo "✔ Done. See results in: $OUTPUT"
